
void strong(int n);
void strong(int n)

{
    int k,R,i,nn,f;

    k=n;nn=0;
    for(k=n;k!=0;k/=10)
    {
        R=k%10;
        f=1;
        for(i=1;i<=R;i++)
        {
            f=f*i;
        }
        nn=nn+f;
    }
    if(n==nn)
    {
        printf("\n%d is a strong number",n);
    }
    else
    {
        printf("\n%d is not a strong number",n);
    }
}
