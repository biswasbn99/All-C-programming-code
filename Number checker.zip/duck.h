void duck(int );

void duck(int n)
{
  int temp,D,R;
 temp=n;D=0;
    for(temp=n;temp!=0;temp/=10)
    {
        R=temp%10;
        if(R==0)
        {
            D++;
            break;
        }

    }
    if(D==1)
    {
        printf("%d is a Duck number",n);
    }
    else
    {
        printf("%d is not a duck number",n);
    }
}
