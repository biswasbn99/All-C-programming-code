
void prime(int n);
void prime(int n)

{
   int d,f=0;

    for(d=2;d<=(n/2);d++)
    {
        if(n%d==0)
        {
            f++;
            break;
        }
    }

    if(f==0)
       {
           printf("%d is a prime number",n);
       }
        else
        {
            printf("%d is not a prime number",n);
        }
}
