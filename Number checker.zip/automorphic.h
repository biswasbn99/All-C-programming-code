
void automorphic(int n);

void automorphic(int n)
{
    int temp,sqr,c;
    temp=n;
    sqr=temp*temp;
    c=1;
    for(temp=n;temp!=0;temp/=10)
    {
        c=c*10;
}

if(sqr%c==n)
{
    printf("%d is an Automorphic number\n",n);
}
else
{
    printf("%d is not an automorphic number\n",n);
}

}
