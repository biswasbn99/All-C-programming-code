#include<stdio.h>
#include<math.h>
#include "prime.h"
#include "palindrome.h"
#include "armstrong.h"
#include "strong.h"
#include "adam.h"
#include "sunny.h"
#include "duck.h"
#include "automorphic.h"
#include "strange.h"
#include "magic.h"
main()
{
    int n,T;
    printf("Input the number:\n");
    scanf("%d",&n);
    printf("Press 1 for checking  prime number:\n");
    printf("Press 2 for checking  palindrome number:\n");
    printf("Press 3 for checking  Armstrong number:\n");
    printf("Press 4 for checking  Strong number:\n");
    printf("Press 5 for checking  Adam number:\n");
    printf("Press 6 for checking  Sunny number:\n");
    printf("Press 7 for checking  Duck number:\n");
    printf("Press 8 for checking  Automorphic number:\n");
    printf("Press 9 for checking  Strange number:\n");
    printf("Press 10 for checking  magic number:\n");
    scanf("%d",&T);

    switch(T)
    {
        case 1: prime(n);
        break;
        case 2: palindrome(n);
        break;
        case 3: armstrong(n);
        break;
        case 4: strong(n);
        break;
        case 5: adam(n);
        break;
        case 6: sunny(n);
        break;
        case 7: duck(n);
        break;
        case 8: automorphic(n);
        break;
        case 9: strange(n);
        break;
        case 10: magic(n);
        break;
        default:
            printf("Invalid Number");
    }



}
