int rev(int n);
void adam(int n);

int rev(int n)
{
    int s=0,R;
    while(n!=0)
    {
        R=n%10;
        s=(s*10)+R;
        n/=10;
    }

    return s;
}

void adam(int n)
{
    int sqr,p,k,m;
    sqr=n*n;
    p=rev(sqr);
    k=rev(n);
    m=k*k;
    if(m==p)
    {
        printf("%d is an Adam number",n);
    }
    else
    {
        printf("%d is not an Adam number",n);
    }
}
