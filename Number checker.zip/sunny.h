

void sunny(int n);

void sunny(int n)
{
    double R;
    R = sqrt(n + 1);
    if ((int)R == R)
    {
        printf("%d is a sunny number\n",n);
    }
    else
    {
        printf("%d is not a sunny number\n",n);
    }
}
